#Python file to initialize the package

from .operations import addition,subtraction,multiplication,division
