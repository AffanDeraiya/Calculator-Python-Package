# Python file with all the basic calculator operations

def addition(a,b):
    return a + b   #Return addition of a and b

def subtraction(a,b):
    return a - b   #Return subtraction of a and b

def multiplication(a,b):
    return a * b   #Return multiplication of a and b

def division(a,b):
    return a / b if b!=0 else "Cannot divide by zero"    #Return Division of a and b