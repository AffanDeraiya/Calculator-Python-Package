# setup.py

from setuptools import setup, find_packages

setup(
    name="mypackage",
    version="0.1",
    description="Package for basic calculator functionalities",
    author="Affan Deraiya",
    packages=find_packages(),
    install_requires=[],
)
