from calculator_package import addition, subtraction,multiplication,division

result_add = addition(10, 3)
result_subtract = subtraction(15, 3)
result_multiplication = multiplication(45, 3)
result_division = division(27, 3)

print(f"Addition: {result_add}")
print(f"Subtraction: {result_subtract}")
print(f"Multiplication: {result_multiplication}")
print(f"Division: {result_division}")
